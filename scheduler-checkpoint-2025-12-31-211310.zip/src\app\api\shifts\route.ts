import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const shifts = await prisma.shift.findMany({
      include: {
        employee: true,
      },
      orderBy: {
        startTime: 'asc',
      },
    });
    return NextResponse.json(shifts);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch shifts' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { userId, employeeId, title, startTime, endTime, position, notes, color } = body;

    const shift = await prisma.shift.create({
      data: {
        userId,
        employeeId,
        title,
        startTime: new Date(startTime),
        endTime: new Date(endTime),
        position,
        notes,
        color,
      },
      include: {
        employee: true,
      },
    });

    return NextResponse.json(shift, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to create shift' },
      { status: 500 }
    );
  }
}
