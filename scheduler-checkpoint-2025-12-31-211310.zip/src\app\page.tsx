export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Navigation */}
      <nav className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-4xl">📅</span>
            <span className="text-2xl font-bold text-white">Scheduler Pro</span>
          </div>
          <div className="flex items-center space-x-4">
            <a href="/dashboard" className="text-gray-300 hover:text-white transition-colors">Features</a>
            <a href="#pricing" className="text-gray-300 hover:text-white transition-colors">Pricing</a>
            <a href="/dashboard" className="text-gray-300 hover:text-white transition-colors px-4 py-2 border border-gray-600 rounded-lg hover:border-purple-500">Login</a>
            <a href="/dashboard" className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-lg font-semibold hover:from-blue-600 hover:to-purple-700 transition-all shadow-lg shadow-purple-500/30">
              Start Free →
            </a>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <header className="text-center mb-20">
          <div className="inline-block mb-6 px-4 py-2 bg-purple-500/20 rounded-full border border-purple-500/30">
            <span className="text-purple-300 text-sm font-semibold">✨ Trusted by 10,000+ businesses</span>
          </div>
          <h1 className="text-6xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Schedule Smarter,<br />
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Work Better
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto mb-8">
            Transform your workforce management with AI-powered scheduling, 
            intuitive drag-and-drop interfaces, and real-time collaboration.
          </p>
          <div className="flex items-center justify-center space-x-4">
            <a href="/dashboard" className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:from-blue-600 hover:to-purple-700 transform hover:scale-105 transition-all shadow-lg shadow-purple-500/50">
              Start Free Trial
            </a>
            <button className="bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-white/20 transition-all border border-white/20">
              Watch Demo
            </button>
          </div>
          <p className="text-gray-400 text-sm mt-4">No credit card required • 14-day free trial</p>
        </header>

        {/* Google Reviews Section */}
        <div className="mb-20 text-center">
          <div className="inline-flex items-center space-x-3 bg-white/10 backdrop-blur-sm px-8 py-4 rounded-2xl border border-white/20">
            <div className="flex items-center space-x-1">
              <span className="text-yellow-400 text-2xl">⭐</span>
              <span className="text-yellow-400 text-2xl">⭐</span>
              <span className="text-yellow-400 text-2xl">⭐</span>
              <span className="text-yellow-400 text-2xl">⭐</span>
              <span className="text-yellow-400 text-2xl">⭐</span>
            </div>
            <div className="border-l border-white/20 pl-4">
              <div className="text-white font-bold text-xl">4.9/5.0</div>
              <div className="text-gray-400 text-sm">2,847 reviews on Google</div>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:border-purple-500/50 transition-all">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mb-4">
              <span className="text-2xl">📊</span>
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Intelligent Scheduling</h3>
            <p className="text-gray-400">AI-powered suggestions optimize your schedule based on availability, skills, and labor costs.</p>
          </div>
          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:border-pink-500/50 transition-all">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center mb-4">
              <span className="text-2xl">🎯</span>
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Drag & Drop Magic</h3>
            <p className="text-gray-400">Effortlessly build schedules with our intuitive visual interface. Changes sync in real-time.</p>
          </div>
          <div className="bg-gradient-to-br from-pink-500/10 to-orange-500/10 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:border-orange-500/50 transition-all">
            <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-orange-600 rounded-xl flex items-center justify-center mb-4">
              <span className="text-2xl">⚡</span>
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Real-Time Updates</h3>
            <p className="text-gray-400">Everyone stays in sync with instant notifications and mobile-friendly access anywhere.</p>
          </div>
        </div>

        {/* Customer Testimonials */}
        <div className="grid md:grid-cols-3 gap-6 mb-20">
          <div className="bg-white/5 backdrop-blur-sm p-6 rounded-xl border border-white/10">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-purple-600 rounded-full"></div>
              <div className="ml-3">
                <div className="text-white font-semibold">Sarah Johnson</div>
                <div className="text-gray-400 text-sm">Restaurant Manager</div>
              </div>
            </div>
            <div className="text-yellow-400 mb-2">⭐⭐⭐⭐⭐</div>
            <p className="text-gray-300 text-sm">"Scheduling used to take me hours. Now it's done in minutes. The drag-and-drop is a game changer!"</p>
          </div>
          <div className="bg-white/5 backdrop-blur-sm p-6 rounded-xl border border-white/10">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-blue-600 rounded-full"></div>
              <div className="ml-3">
                <div className="text-white font-semibold">Mike Chen</div>
                <div className="text-gray-400 text-sm">Retail Store Owner</div>
              </div>
            </div>
            <div className="text-yellow-400 mb-2">⭐⭐⭐⭐⭐</div>
            <p className="text-gray-300 text-sm">"The AI scheduling suggestions saved us 30% on labor costs. Incredible ROI!"</p>
          </div>
          <div className="bg-white/5 backdrop-blur-sm p-6 rounded-xl border border-white/10">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-pink-400 to-orange-600 rounded-full"></div>
              <div className="ml-3">
                <div className="text-white font-semibold">Emily Rodriguez</div>
                <div className="text-gray-400 text-sm">Healthcare Director</div>
              </div>
            </div>
            <div className="text-yellow-400 mb-2">⭐⭐⭐⭐⭐</div>
            <p className="text-gray-300 text-sm">"Finally, a scheduling tool that our entire team actually wants to use. Support is amazing!"</p>
          </div>
        </div>

        {/* Pricing Section */}
        <div id="pricing" className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Choose Your Power Level</h2>
          <p className="text-gray-400 text-lg">Start free and scale as you grow. No hidden fees, cancel anytime.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {/* Free Tier */}
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 border border-slate-700 hover:border-blue-500 transition-all transform hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/20">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white mb-2">Free</h2>
              <div className="flex items-baseline mb-4">
                <span className="text-5xl font-bold text-white">$0</span>
                <span className="text-gray-400 ml-2">/month</span>
              </div>
              <p className="text-gray-400">Perfect for small teams getting started</p>
            </div>
            <ul className="space-y-4 mb-8">
              <li className="flex items-start text-gray-300">
                <span className="text-green-400 mr-3 text-xl">✓</span>
                <span><strong className="text-white">Up to 10</strong> employees</span>
              </li>
              <li className="flex items-start text-gray-300">
                <span className="text-green-400 mr-3 text-xl">✓</span>
                <span>Week & month calendar views</span>
              </li>
              <li className="flex items-start text-gray-300">
                <span className="text-green-400 mr-3 text-xl">✓</span>
                <span>Manual shift assignments</span>
              </li>
              <li className="flex items-start text-gray-300">
                <span className="text-green-400 mr-3 text-xl">✓</span>
                <span>Basic reporting</span>
              </li>
              <li className="flex items-start text-gray-300">
                <span className="text-green-400 mr-3 text-xl">✓</span>
                <span>Email support</span>
              </li>
            </ul>
            <a href="/dashboard" className="block w-full bg-gradient-to-r from-slate-700 to-slate-600 text-white py-4 rounded-xl font-bold text-center hover:from-slate-600 hover:to-slate-500 transition-all">
              Start Free
            </a>
          </div>

          {/* Gold Tier - Featured */}
          <div className="bg-gradient-to-br from-yellow-500 via-yellow-600 to-orange-600 rounded-2xl p-8 border-4 border-yellow-400 transform scale-110 shadow-2xl shadow-yellow-500/50 relative">
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-yellow-400 to-orange-400 text-slate-900 px-6 py-2 rounded-full text-sm font-black shadow-lg">
              🔥 MOST POPULAR
            </div>
            <div className="mb-6 mt-4">
              <h2 className="text-2xl font-bold text-white mb-2">Gold</h2>
              <div className="flex items-baseline mb-4">
                <span className="text-5xl font-bold text-white">$29</span>
                <span className="text-yellow-100 ml-2">/month</span>
              </div>
              <p className="text-yellow-100">For growing teams that need more power</p>
            </div>
            <ul className="space-y-4 mb-8">
              <li className="flex items-start text-white">
                <span className="text-yellow-200 mr-3 text-xl">✓</span>
                <span><strong>Up to 50</strong> employees</span>
              </li>
              <li className="flex items-start text-white">
                <span className="text-yellow-200 mr-3 text-xl">✓</span>
                <span><strong>All calendar views</strong> with drag-and-drop</span>
              </li>
              <li className="flex items-start text-white">
                <span className="text-yellow-200 mr-3 text-xl">✓</span>
                <span>Time-off management</span>
              </li>
              <li className="flex items-start text-white">
                <span className="text-yellow-200 mr-3 text-xl">✓</span>
                <span>Shift swapping & trading</span>
              </li>
              <li className="flex items-start text-white">
                <span className="text-yellow-200 mr-3 text-xl">✓</span>
                <span><strong>Advanced reporting</strong> & analytics</span>
              </li>
              <li className="flex items-start text-white">
                <span className="text-yellow-200 mr-3 text-xl">✓</span>
                <span>SMS & Email notifications</span>
              </li>
              <li className="flex items-start text-white">
                <span className="text-yellow-200 mr-3 text-xl">✓</span>
                <span>Priority support</span>
              </li>
            </ul>
            <a href="/dashboard" className="block w-full bg-white text-yellow-600 py-4 rounded-xl font-bold text-center hover:bg-yellow-50 transition-all shadow-lg">
              Start 14-Day Trial
            </a>
          </div>

          {/* Platinum Tier */}
          <div className="bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 rounded-2xl p-8 border-2 border-purple-500 hover:border-purple-400 transition-all transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/20">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white mb-2">Platinum</h2>
              <div className="flex items-baseline mb-4">
                <span className="text-5xl font-bold text-white">$99</span>
                <span className="text-purple-300 ml-2">/month</span>
              </div>
              <p className="text-purple-300">Enterprise-grade for unlimited scale</p>
            </div>
            <ul className="space-y-4 mb-8">
              <li className="flex items-start text-purple-100">
                <span className="text-purple-300 mr-3 text-xl">✓</span>
                <span><strong className="text-white">Unlimited</strong> employees</span>
              </li>
              <li className="flex items-start text-purple-100">
                <span className="text-purple-300 mr-3 text-xl">✓</span>
                <span><strong className="text-white">All Gold features</strong></span>
              </li>
              <li className="flex items-start text-purple-100">
                <span className="text-purple-300 mr-3 text-xl">✓</span>
                <span><strong className="text-white">AI-powered</strong> scheduling suggestions</span>
              </li>
              <li className="flex items-start text-purple-100">
                <span className="text-purple-300 mr-3 text-xl">✓</span>
                <span>Availability management</span>
              </li>
              <li className="flex items-start text-purple-100">
                <span className="text-purple-300 mr-3 text-xl">✓</span>
                <span>Advanced analytics dashboard</span>
              </li>
              <li className="flex items-start text-purple-100">
                <span className="text-purple-300 mr-3 text-xl">✓</span>
                <span>Export/Import capabilities</span>
              </li>
              <li className="flex items-start text-purple-100">
                <span className="text-purple-300 mr-3 text-xl">✓</span>
                <span>Custom branding</span>
              </li>
              <li className="flex items-start text-purple-100">
                <span className="text-purple-300 mr-3 text-xl">✓</span>
                <span><strong className="text-white">24/7 Priority</strong> support</span>
              </li>
              <li className="flex items-start text-purple-100">
                <span className="text-purple-300 mr-3 text-xl">✓</span>
                <span>Dedicated account manager</span>
              </li>
            </ul>
            <a href="/dashboard" className="block w-full bg-gradient-to-r from-purple-500 to-indigo-600 text-white py-4 rounded-xl font-bold text-center hover:from-purple-600 hover:to-indigo-700 transition-all shadow-lg">
              Start 14-Day Trial
            </a>
          </div>
        </div>

        {/* Social Proof */}
        <div className="mt-20 text-center">
          <p className="text-gray-400 mb-8">Trusted by leading companies worldwide</p>
          <div className="flex items-center justify-center space-x-12 text-gray-600">
            <div className="text-2xl font-bold">Company A</div>
            <div className="text-2xl font-bold">Company B</div>
            <div className="text-2xl font-bold">Company C</div>
            <div className="text-2xl font-bold">Company D</div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-20 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-3xl p-12 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">Ready to Transform Your Scheduling?</h2>
          <p className="text-xl text-blue-100 mb-8">Join thousands of businesses already saving time and money</p>
          <a href="/dashboard" className="inline-block bg-white text-purple-600 px-10 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-all shadow-2xl transform hover:scale-105">
            Get Started Free →
          </a>
        </div>
      </div>
    </div>
  );
}
