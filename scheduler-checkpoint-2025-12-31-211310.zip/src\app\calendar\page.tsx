'use client';

import { useState } from 'react';
import BigCalendar from '@/components/BigCalendar';
import { Plus, Filter, Printer, Download } from 'lucide-react';

export default function CalendarPage() {
  const [events] = useState([
    {
      id: '1',
      title: 'John Doe - Morning Shift',
      start: new Date(2025, 11, 30, 9, 0),
      end: new Date(2025, 11, 30, 17, 0),
      employeeId: '1',
      employeeName: 'John Doe',
      position: 'Manager',
      color: '#3b82f6',
    },
    {
      id: '2',
      title: 'Jane Smith - Evening Shift',
      start: new Date(2025, 11, 30, 13, 0),
      end: new Date(2025, 11, 30, 21, 0),
      employeeId: '2',
      employeeName: 'Jane Smith',
      position: 'Staff',
      color: '#10b981',
    },
    {
      id: '3',
      title: 'Mike Johnson - Full Day',
      start: new Date(2025, 11, 31, 8, 0),
      end: new Date(2025, 11, 31, 16, 0),
      employeeId: '3',
      employeeName: 'Mike Johnson',
      position: 'Staff',
      color: '#8b5cf6',
    },
  ]);

  const handlePrint = () => {
    window.print();
  };

  const handleExportPDF = () => {
    alert('PDF export feature! This would generate a professional PDF of your schedule with all shifts and employee details.');
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-2xl p-8 shadow-2xl">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="text-4xl font-bold text-white">Schedule Calendar</h2>
            <p className="text-blue-100 mt-2 text-lg">Manage and view all employee shifts</p>
          </div>
          
          <div className="flex gap-3 flex-wrap">
            <button 
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm text-white border border-white/30 rounded-xl hover:bg-white/30 transition-all shadow-lg"
            >
              <Printer className="h-5 w-5" />
              Print
            </button>
            <button 
              onClick={handleExportPDF}
              className="flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm text-white border border-white/30 rounded-xl hover:bg-white/30 transition-all shadow-lg"
            >
              <Download className="h-5 w-5" />
              Export PDF
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm text-white border border-white/30 rounded-xl hover:bg-white/30 transition-all shadow-lg">
              <Filter className="h-5 w-5" />
              Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-white text-purple-600 rounded-xl hover:bg-blue-50 transition-all shadow-lg font-semibold">
              <Plus className="h-5 w-5" />
              Add Shift
            </button>
          </div>
        </div>
      </div>

      <BigCalendar
        events={events}
        onSelectSlot={(slotInfo) => {
          console.log('Selected slot:', slotInfo);
        }}
        onSelectEvent={(event) => {
          console.log('Selected event:', event);
        }}
        enableDragAndDrop={true}
      />
    </div>
  );
}
