# Employee Scheduler Project - Copilot Instructions

## Project Overview
Building a comprehensive employee scheduling application with subscription tiers and a beautiful, user-friendly interface.

## Tech Stack
- Next.js 14+ (App Router)
- TypeScript
- Tailwind CSS
- Prisma ORM
- PostgreSQL/SQLite
- React Big Calendar or FullCalendar
- Shadcn/ui components

## Key Features
- Large, intuitive calendar interface (day/week/month views)
- Three subscription tiers: Free, Gold, Platinum
- Employee management (CRUD operations)
- Shift scheduling with drag-and-drop
- Time-off request management
- Shift swapping and trading
- Availability management
- Reporting and analytics dashboard
- Notifications system
- Authentication and authorization
- Responsive design

## Development Guidelines
- Use TypeScript strictly with proper type definitions
- Follow Next.js App Router conventions
- Keep components modular and reusable
- Use Tailwind CSS for styling
- Implement proper error handling
- Add loading states and optimistic UI updates
- Follow accessibility best practices
- Ensure mobile responsiveness

## Subscription Tier Features
### Free Tier
- Basic employee management (up to 10 employees)
- Simple calendar view (week/month)
- Manual shift assignments
- Basic reporting

### Gold Tier
- Up to 50 employees
- All calendar views with drag-and-drop
- Time-off request management
- Shift swapping
- Advanced reporting
- Email notifications

### Platinum Tier
- Unlimited employees
- All Gold features
- Availability management
- Automated scheduling suggestions
- Advanced analytics
- Priority support
- Export/import capabilities
- Custom branding
