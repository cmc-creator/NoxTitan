export const TIER_LIMITS = {
  FREE: {
    maxEmployees: 10,
    features: {
      calendarViews: ['week', 'month'],
      dragAndDrop: false,
      timeOffRequests: false,
      shiftSwapping: false,
      availability: false,
      advancedReporting: false,
      notifications: false,
      autoScheduling: false,
      analytics: false,
      exportImport: false,
      customBranding: false,
    }
  },
  GOLD: {
    maxEmployees: 50,
    features: {
      calendarViews: ['day', 'week', 'month'],
      dragAndDrop: true,
      timeOffRequests: true,
      shiftSwapping: true,
      availability: false,
      advancedReporting: true,
      notifications: true,
      autoScheduling: false,
      analytics: false,
      exportImport: false,
      customBranding: false,
    }
  },
  PLATINUM: {
    maxEmployees: -1, // Unlimited
    features: {
      calendarViews: ['day', 'week', 'month'],
      dragAndDrop: true,
      timeOffRequests: true,
      shiftSwapping: true,
      availability: true,
      advancedReporting: true,
      notifications: true,
      autoScheduling: true,
      analytics: true,
      exportImport: true,
      customBranding: true,
    }
  }
} as const;

export type SubscriptionTier = keyof typeof TIER_LIMITS;
